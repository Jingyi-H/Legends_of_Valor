public class Spirit extends Monster {
    public Spirit() {}

    public Spirit(String name, int level, int damage, int defense, int dodgeChance) {
        super(name, level, damage, defense, dodgeChance);
    }
}
