public class KoulouCell extends Cell{
	
	public KoulouCell() {
		super();
		this.marker.add("|##|");
		this.marker.add("|##|");
		this.name = "KoulouCell";
	}

}
