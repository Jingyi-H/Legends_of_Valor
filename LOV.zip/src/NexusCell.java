public class NexusCell extends Cell {
    public NexusCell() {
        super();
        marker.add("/``\\");
        marker.add("|__|");
        name = "NexusCell";
    }
}
