public class BushCell extends Cell{
	
	public BushCell() {
		super();
		this.marker.add("^^^^");
		this.marker.add("^^^^");
		this.name = "BushCell";
	}

}
