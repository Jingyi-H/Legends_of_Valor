public class HMBoard {
    Cell[][] board;
    int size;
}
