public class PlainCell extends Cell {
    public PlainCell() {
        super();
        marker.add("    ");
        marker.add("    ");
        name = "PlainCell";
    }
}
