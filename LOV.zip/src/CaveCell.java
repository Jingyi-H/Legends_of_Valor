public class CaveCell extends Cell {
	
	public CaveCell() {
		this.marker.add("/"+"--"+"\\");
		this.marker.add("\\"+"__"+"/");
		
		this.name = "CaveCell";
		
	}

}
