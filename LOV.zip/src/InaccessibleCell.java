public class InaccessibleCell extends Cell {
    public InaccessibleCell() {
        super();
        marker.add("XXXX");
        marker.add("XXXX");
        name = "InaccessibleCell";
    }
}
