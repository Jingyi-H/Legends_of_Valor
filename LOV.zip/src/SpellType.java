public enum SpellType {
    ICE,
    FIRE,
    LIGHTNING
}
